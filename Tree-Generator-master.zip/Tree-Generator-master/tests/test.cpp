#include "treegenerator.h"
#include <iostream>

using namespace std;

int main()
{
    cout << tree_generator_by_ouuan::Tree("rd100,0lh100,0.1,0.7,77tl100,3,114ch233,6st773,514fl2434,773md114,4,514lm191,9,0.3,0.9,810cp2333,7,666bi666,2434cb666,999sw100,333al1919,114,514nd121");

    return 0;
}